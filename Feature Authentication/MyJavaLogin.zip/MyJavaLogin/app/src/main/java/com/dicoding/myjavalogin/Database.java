package com.dicoding.myjavalogin;

public class Database {
    public static String ip = "192.168.1.10";

    public static final String urlRegister = "http://"+ip+"/capstone/user/api-register.php";
    public static final String urlLogin = "http://"+ip+"/capstone/user/api-login.php";
}
