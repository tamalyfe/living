package com.example.living.userInterface.mainPage.featurePage.projectPage.viewModel;

public class ViewModelReadProjectPage {
}
