package com.example.living.data.remote.retrofit.requestCustomer;

public class ApiConfigReadRequestCustomerPage {
}
