package com.example.living.data.remote.retrofit.recruitmentCustomer;

public class ApiConfigReadRecruitmentTeamPage {
}
