package com.example.living.data.local.preferences;

public class Preference {
}
