package com.example.living.utility;

public class Utility {
}
