package com.example.living.utility;

public class Result {
}
