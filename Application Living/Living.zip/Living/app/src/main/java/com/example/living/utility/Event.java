package com.example.living.utility;

public class Event {
}
