package com.example.living.data.remote.retrofit.project;

public class ApiConfigReadProjectPage {
}
