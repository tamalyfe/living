package com.example.living.userInterface.mainPage.featurePage.requestCustomerPage.viewModel;

public class ViewModelReadRequestCustomerPage {
}
