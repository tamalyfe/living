package com.example.living.userInterface.mainPage.homePage;

import android.content.Intent;
import android.os.Bundle;

import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;
import com.example.living.R;
import com.example.living.userInterface.mainPage.NotificationMainPageActivity;
import com.example.living.userInterface.mainPage.WishListMainPageActivity;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class HomePageFragment extends Fragment {
    CardView cvReadHomePageActivity;

    private FloatingActionButton fab;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.home_page_fragment, null);

        // final Toolbar tTitle = v.findViewById(R.id.t_Title);
        // tTitle.setTitle("Title");
        // tTitle.setTitleTextAppearance(getContext(), R.style.setTitleTextAppearance);
        // tTitle.setTitleTextColor(getResources().getColor(R.color.white));
        // tTitle.setTitleTextColor(Color.parseColor("#FFFFFFFF"));

        /*
                FloatingActionButton fabLink = v.findViewById(R.id.fab_Link);
        fabLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getContext(), Link.class);
                startActivity(intent);
                Toast.makeText(getContext(), "Link", Toast.LENGTH_SHORT).show();
            }
        });

      fab = v.findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(getContext(), FragmentActivityPopupWindow.class);
                startActivity(intent);
                Toast.makeText(getContext(), "fab", Toast.LENGTH_SHORT).show();
            }
        });
        */

        cvReadHomePageActivity = v.findViewById(R.id.cvHomePage);
        cvReadHomePageActivity.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(getContext(), ReadHomePageActivity.class);
                startActivity(intent);
                Toast.makeText(getContext(), "Read Home Page Activity", Toast.LENGTH_SHORT).show();
            }
        });

        FloatingActionButton fabWishList = v.findViewById(R.id.fabWishList);
        fabWishList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getContext(), WishListMainPageActivity.class);
                startActivity(intent);
                Toast.makeText(getContext(), "WishList", Toast.LENGTH_SHORT).show();
            }
        });

        FloatingActionButton fabNotification = v.findViewById(R.id.fabNotification);
        fabNotification.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getContext(), NotificationMainPageActivity.class);
                startActivity(intent);
                Toast.makeText(getContext(), "Notification", Toast.LENGTH_SHORT).show();
            }
        });

        return v;
        // return inflater.inflate(R.layout.home_fragment, null);
    }
}