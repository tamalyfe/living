package com.example.living.data.local.backgroundService;

public class BackgroundService {
}
