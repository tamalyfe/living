package com.example.living.data.remote.response.requestCustomer;

public class ItemResponseRequestCustomer {
    String identifier_request_customer;
    String name_customer;
    String contact_customer;
    String domicile_customer;
    String description_request_customer;
    String location_project;
    String price_list_project_cash;
    String price_list_project_credit;
    String status_project;

    public String getIdentifierRequestCustomer() {
        return identifier_request_customer;
    }

    public String getNameCustomer() {
        return name_customer;
    }

    public String getContactCustomer() {
        return contact_customer;
    }

    public String getDomicileCustomer() {
        return domicile_customer;
    }

    public String getDescriptionRequestCustomer() {
        return description_request_customer;
    }

    public String getLocationProject() {
        return location_project;
    }

    public String getPriceListProjectCash() {
        return price_list_project_cash;
    }

    public String getPriceListProjectCredit() {
        return price_list_project_credit;
    }

    public String getStatusProject() {
        return status_project;
    }
}
