package com.example.living.data.local.injection;

public class Injection {
}
