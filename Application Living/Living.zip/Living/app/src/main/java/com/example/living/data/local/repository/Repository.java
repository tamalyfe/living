package com.example.living.data.local.repository;

public class Repository {
}
