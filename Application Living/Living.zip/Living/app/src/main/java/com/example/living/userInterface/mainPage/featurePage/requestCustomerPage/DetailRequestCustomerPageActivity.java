package com.example.living.userInterface.mainPage.featurePage.requestCustomerPage;

import android.content.ActivityNotFoundException;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.text.style.ForegroundColorSpan;
import android.text.style.RelativeSizeSpan;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;

import com.example.living.R;
import com.example.living.data.remote.response.requestCustomer.ResponseRequestCustomer;
import com.example.living.userInterface.mainPage.featurePage.requestCustomerPage.viewModel.ViewModelDetailRequestCustomerPage;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class DetailRequestCustomerPageActivity extends AppCompatActivity {
    private ViewModelDetailRequestCustomerPage viewModel;

    @BindView(R.id.tvIdentifierRequestCustomer) TextView tvIdentifierRequestCustomer;
    @BindView(R.id.tvNameCustomer) TextView tvNameCustomer;
    @BindView(R.id.tvContactCustomer) TextView tvContactCustomer;
    @BindView(R.id.tvDomicileCustomer) TextView tvDomicileCustomer;
    @BindView(R.id.tvDescriptionRequestCustomer) TextView tvDescriptionRequestCustomer;
    @BindView(R.id.tvLocationProject) TextView tvLocationProject;
    @BindView(R.id.tvPriceListProjectCash) TextView tvPriceListProjectCash;
    @BindView(R.id.tvPriceListProjectCredit) TextView tvPriceListProjectCredit;
    @BindView(R.id.tvStatusProject) TextView tvStatusProject;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.detail_request_customer_page_activity);

        viewModel = new ViewModelProvider(this, new ViewModelProvider.NewInstanceFactory()).get(ViewModelDetailRequestCustomerPage.class);

        ButterKnife.bind(this);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("Detail Request Customer");

        setupUIDetailRequestCustomerPageActivity();
        setupDetailRequestCustomerPageActivity();
    }

    private void setupUIDetailRequestCustomerPageActivity() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setFlags(
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
            getWindow().setStatusBarColor(Color.GRAY);
        }

        getSupportActionBar().hide();

        final Toolbar tDetailRequestCustomerPageActivity = findViewById(R.id.tDetailRequestCustomerPageActivity);
        tDetailRequestCustomerPageActivity.setNavigationIcon(R.drawable.ic_keyboard_arrow_left_dark_green_36dp);
        tDetailRequestCustomerPageActivity.setTitle("Detail Request Customer");
        tDetailRequestCustomerPageActivity.setTitleTextAppearance(getApplicationContext(), R.style.setTitleTextAppearance);
        tDetailRequestCustomerPageActivity.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        Intent intent = getIntent();
        String contactCustomer = intent.getStringExtra("contact_customer");
        tvContactCustomer.setText(contactCustomer);
        makeClickableWhatsAppLink(contactCustomer);
    }

    private void makeClickableWhatsAppLink(String phoneNumber) {
        SpannableString spannable = new SpannableString("WhatsApp : " + phoneNumber);

        ClickableSpan clickableSpan = new ClickableSpan() {
            @Override
            public void onClick(View widget) {
                openWhatsApp(phoneNumber);
            }
        };

        spannable.setSpan(clickableSpan, 10, spannable.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

        spannable.setSpan(new ForegroundColorSpan(Color.BLUE), 0, 9, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        spannable.setSpan(new RelativeSizeSpan(0.8f), 0, 9, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

        tvContactCustomer.setMovementMethod(LinkMovementMethod.getInstance());
        tvContactCustomer.setText(spannable, TextView.BufferType.SPANNABLE);
    }

    private void openWhatsApp(String phoneNumber) {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setData(Uri.parse("http://api.whatsapp.com/send?phone=" + phoneNumber));
            startActivity(intent);
        } catch (ActivityNotFoundException e) {
            e.printStackTrace();
            Toast.makeText(this, "WhatsApp not Installed", Toast.LENGTH_SHORT).show();
        }
    }

    private void setupDetailRequestCustomerPageActivity() {
        Intent intent = getIntent();
        String identifierRequestCustomer = intent.getStringExtra("identifier_request_customer");
        String nameCustomer = intent.getStringExtra("name_customer");
        String contactCustomer = intent.getStringExtra("contact_customer");
        String domicileCustomer = intent.getStringExtra("domicile_customer");
        String descriptionRequestCustomer = intent.getStringExtra("description_request_customer");
        String locationProject = intent.getStringExtra("location_project");
        String priceListProjectCash = intent.getStringExtra("price_list_project_cash");
        String priceListProjectCredit = intent.getStringExtra("price_list_project_credit");
        String statusProject = intent.getStringExtra("status_project");

        tvIdentifierRequestCustomer.setText(identifierRequestCustomer);
        tvNameCustomer.setText(nameCustomer);
        tvContactCustomer.setText(contactCustomer);
        tvDomicileCustomer.setText(domicileCustomer);
        tvDescriptionRequestCustomer.setText(descriptionRequestCustomer);
        tvLocationProject.setText(locationProject);
        tvPriceListProjectCash.setText(priceListProjectCash);
        tvPriceListProjectCredit.setText(priceListProjectCredit);
        tvStatusProject.setText(statusProject);
    }

    @OnClick(R.id.fabUpdateRequestCustomerPageActivity)
    void openNewActivity() {
        String identifierRequestCustomer = tvIdentifierRequestCustomer.getText().toString();
        String nameCustomer = tvNameCustomer.getText().toString();
        String contactCustomer = tvContactCustomer.getText().toString();
        String domicileCustomer = tvDomicileCustomer.getText().toString();
        String descriptionRequestCustomer = tvDescriptionRequestCustomer.getText().toString();
        String locationProject = tvLocationProject.getText().toString();
        String priceListProjectCash = tvPriceListProjectCash.getText().toString();
        String priceListProjectCredit = tvPriceListProjectCredit.getText().toString();
        String statusProject = tvStatusProject.getText().toString();

        Intent intent = new Intent(this, UpdateRequestCustomerPageActivity.class);
        intent.putExtra("identifier_request_customer", identifierRequestCustomer);
        intent.putExtra("name_customer", nameCustomer);
        intent.putExtra("contact_customer", contactCustomer);
        intent.putExtra("domicile_customer", domicileCustomer);
        intent.putExtra("description_request_customer", descriptionRequestCustomer);
        intent.putExtra("location_project", locationProject);
        intent.putExtra("price_list_project_cash", priceListProjectCash);
        intent.putExtra("price_list_project_credit", priceListProjectCredit);
        intent.putExtra("status_project", statusProject);
        this.startActivity(intent);
    }

    @OnClick(R.id.fabDeleteRequestCustomerPageActivity)
    void showDeleteConfirmationDialog() {
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
        alertDialogBuilder.setTitle("Attention");
        alertDialogBuilder
                .setMessage("Check")
                .setCancelable(false)
                .setPositiveButton("Delete", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        String identifierRequestCustomer = tvIdentifierRequestCustomer.getText().toString();
                        viewModel.deleteRequestCustomer(identifierRequestCustomer);
                    }
                })
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });

        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();

        viewModel.getResponseLiveData().observe(this, new Observer<ResponseRequestCustomer>() {
            @Override
            public void onChanged(ResponseRequestCustomer response) {
                String value = response.getValue();
                String message = response.getMessage();

                if (value.equals("1")) {
                    Toast.makeText(DetailRequestCustomerPageActivity.this, message, Toast.LENGTH_SHORT).show();
                    finish();
                } else {
                    Toast.makeText(DetailRequestCustomerPageActivity.this, message, Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        setupDetailRequestCustomerPageActivity();
    }
}
