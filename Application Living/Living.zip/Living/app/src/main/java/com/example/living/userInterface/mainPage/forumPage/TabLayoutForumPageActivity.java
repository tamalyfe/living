package com.example.living.userInterface.mainPage.forumPage;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.viewpager.widget.ViewPager;

import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;

import com.example.living.R;
import com.google.android.material.tabs.TabItem;
import com.google.android.material.tabs.TabLayout;

public class TabLayoutForumPageActivity extends AppCompatActivity {
    TabLayout tlForum;
    TabItem tiTimeline;
    TabItem tiLearn;
    TabItem tiHelpSupport;
    ViewPager vpForum;
    ViewPagerForumPageAdapter fpaForum;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tab_layout_forum_page_activity);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
            getWindow().setStatusBarColor(Color.GRAY);
        }

        getSupportActionBar().hide();

        final Toolbar tForum = (Toolbar)findViewById(R.id.tForum);
        tForum.setNavigationIcon(R.drawable.ic_keyboard_arrow_left_dark_green_36dp);
        tForum.setTitle("Forum");
        tForum.setTitleTextAppearance(getApplicationContext(), R.style.setTitleTextAppearance);
        tForum.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        /*
        FloatingActionButton fabLink = (FloatingActionButton)findViewById(R.id.fab_Link);
        fabLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), Link.class);
                startActivity(intent);
                Toast.makeText(getApplicationContext(), "Link", Toast.LENGTH_SHORT).show();
            }
        });

        FloatingActionButton fabInfoNews = (FloatingActionButton)findViewById(R.id.fab_InfoNews);
        fabInfoNews.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), InfoNews.class);
                startActivity(intent);
                Toast.makeText(getApplicationContext(), "Info | News", Toast.LENGTH_SHORT).show();
            }
        });
         */

        tlForum = (TabLayout)findViewById(R.id.tl_Forum);
        tiTimeline = findViewById(R.id.ti_Timeline);
        tiLearn = findViewById(R.id.ti_Learn);
        tiHelpSupport = findViewById(R.id.ti_HelpSupport);
        vpForum = findViewById(R.id.vp_Forum);

        fpaForum = new ViewPagerForumPageAdapter(getSupportFragmentManager(), tlForum.getTabCount());
        vpForum.setAdapter(fpaForum);

        tlForum.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                vpForum.setCurrentItem(tab.getPosition());
                if (tab.getPosition() == 1) { }
                else if (tab.getPosition() == 2) { }
                else if (tab.getPosition() == 3) { }
                else { }
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) { }
            @Override
            public void onTabReselected(TabLayout.Tab tab) { }
        });
        vpForum.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tlForum));
    }
}
