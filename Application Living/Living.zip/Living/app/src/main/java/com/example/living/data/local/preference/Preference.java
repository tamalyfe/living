package com.example.living.data.local.preference;

public class Preference {
}
