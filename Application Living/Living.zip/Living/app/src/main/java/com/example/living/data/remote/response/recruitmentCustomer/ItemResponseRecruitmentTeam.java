package com.example.living.data.remote.response.recruitmentCustomer;

public class ItemResponseRecruitmentTeam {
    String identifier_recruitment_team;
    String name_team;
    String post_team;
    String domicile_team;
    String job_description;
    String experience;
    String certificate;

    public String getIdentifierRecruitmentTeam() {
        return identifier_recruitment_team;
    }

    public String getNameTeam() {
        return name_team;
    }

    public String getPostTeam() {
        return post_team;
    }

    public String getDomicileTeam() {
        return domicile_team;
    }

    public String getJobDescription() {
        return job_description;
    }

    public String getExperience() {
        return experience;
    }

    public String getCertificate() {
        return certificate;
    }
}
