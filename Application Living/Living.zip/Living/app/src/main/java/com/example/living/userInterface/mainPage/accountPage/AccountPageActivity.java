package com.example.living.userInterface.mainPage.accountPage;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Toast;

import com.example.living.userInterface.mainPage.BottomNavigationViewMainPageActivity;
import com.example.living.R;

public class AccountPageActivity extends AppCompatActivity {
    private CardView cvJoinPosition;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.account_page_activity);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
            getWindow().setStatusBarColor(Color.GRAY);
        }

        getSupportActionBar().hide();

        final Toolbar tAccount = (Toolbar)findViewById(R.id.t_Account);
        tAccount.setNavigationIcon(R.drawable.ic_keyboard_arrow_left_dark_green_36dp);
        tAccount.setTitle("Account");
        tAccount.setTitleTextAppearance(getApplicationContext(), R.style.setTitleTextAppearance);
        tAccount.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplication(), BottomNavigationViewMainPageActivity.class);
                startActivity(intent);
                Toast.makeText(getApplication(), "Home", Toast.LENGTH_SHORT).show();
            }
        });

        /*
        cvJoinPosition = (CardView)findViewById(R.id.cv_JoinPosition);
        cvJoinPosition.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), ReadJoinPositionPage.class);
                startActivity(intent);
                Toast.makeText(getApplicationContext(), "Join | Position", Toast.LENGTH_SHORT).show();
            }
        });
         */
    }
}
