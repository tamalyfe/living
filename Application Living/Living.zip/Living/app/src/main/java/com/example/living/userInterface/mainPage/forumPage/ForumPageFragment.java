package com.example.living.userInterface.mainPage.forumPage;

import android.content.Intent;
import android.os.Bundle;

import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.example.living.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class ForumPageFragment extends Fragment {
    CardView cvForum;

    private FloatingActionButton fab;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.forum_page_fragment, null);

        // final Toolbar tTitle = v.findViewById(R.id.t_Title);
        // tTitle.setTitle("Title");
        // tTitle.setTitleTextAppearance(getContext(), R.style.setTitleTextAppearance);
        // tTitle.setTitleTextColor(getResources().getColor(R.color.white));
        // tTitle.setTitleTextColor(Color.parseColor("#FFFFFFFF"));

        /*
        FloatingActionButton fabLink = v.findViewById(R.id.fab_Link);
        fabLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getContext(), Link.class);
                startActivity(intent);
                Toast.makeText(getContext(), "Link", Toast.LENGTH_SHORT).show();
            }
        });

        FloatingActionButton fabWishList = v.findViewById(R.id.fab_WishList);
        fabWishList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getContext(), WishList.class);
                startActivity(intent);
                Toast.makeText(getContext(), "WishList", Toast.LENGTH_SHORT).show();
            }
        });

        FloatingActionButton fabNotification = v.findViewById(R.id.fab_Notification);
        fabNotification.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getContext(), Notification.class);
                startActivity(intent);
                Toast.makeText(getContext(), "Notification", Toast.LENGTH_SHORT).show();
            }
        });

        fab = v.findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(getContext(), FragmentActivityPopUp.class);
                startActivity(intent);
                Toast.makeText(getContext(), "fab", Toast.LENGTH_SHORT).show();
            }
        });
        */

        cvForum = v.findViewById(R.id.cvForumPage);
        cvForum.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), TabLayoutForumPageActivity.class);
                startActivity(intent);
                Toast.makeText(getActivity(), "Forum", Toast.LENGTH_SHORT).show();
            }
        });

        return v;
        // return inflater.inflate(R.layout.forum_fragment, null);
    }
}