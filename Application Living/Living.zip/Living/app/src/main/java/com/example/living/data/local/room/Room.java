package com.example.living.data.local.room;

public class Room {
}
