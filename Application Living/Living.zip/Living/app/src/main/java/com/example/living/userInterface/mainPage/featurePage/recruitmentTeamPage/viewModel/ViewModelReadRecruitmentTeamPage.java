package com.example.living.userInterface.mainPage.featurePage.recruitmentTeamPage.viewModel;

public class ViewModelReadRecruitmentTeamPage {
}
