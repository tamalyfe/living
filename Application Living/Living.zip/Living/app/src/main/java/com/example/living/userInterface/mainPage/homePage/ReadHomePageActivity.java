package com.example.living.userInterface.mainPage.homePage;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;

import com.example.living.R;

import butterknife.ButterKnife;

public class ReadHomePageActivity extends AppCompatActivity { // implements SearchView.OnQueryTextListener
    /*
    public static final String URL = "http://tamafamily.000webhostapp.com/db_tama_family/tb_project_listing_property/";
    private List<DataModelProjectListingProperty> resultNext = new ArrayList<>();
    private RecyclerViewAdapterHome recyclerViewAdapterHome;

    @BindView(R.id.rvNew) RecyclerView rvNew;
    @BindView(R.id.pbNew) ProgressBar pbNew;

    TextView tvBonusPromo;
    TextView tvInfoNews;
    TextView tvNew;
    */

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.read_home_page_activity);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
            getWindow().setStatusBarColor(Color.GRAY);
        }

        getSupportActionBar().hide();

        final Toolbar tHome = (Toolbar) findViewById(R.id.t_ReadHomePageActivity);
        tHome.setNavigationIcon(R.drawable.ic_keyboard_arrow_left_dark_green_36dp);
        tHome.setTitle("Read Home Page Activity");
        tHome.setTitleTextAppearance(getApplicationContext(), R.style.setTitleTextAppearance);
        tHome.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        // OnProgress
        ButterKnife.bind(this);
        // getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("Read Home Page Activity");

        /*
        recyclerViewAdapterHome = new RecyclerViewAdapterHome(this, resultNext);
        // RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
        final LinearLayoutManager layoutManager = new LinearLayoutManager(getApplicationContext(), LinearLayoutManager.HORIZONTAL, true);
        layoutManager.setReverseLayout(true);
        layoutManager.setStackFromEnd(true);
        layoutManager.scrollToPositionWithOffset(0, 0);
        rvNew.setLayoutManager(layoutManager);
        rvNew.setItemAnimator(new DefaultItemAnimator());
        rvNew.smoothScrollToPosition(0);
        rvNew.setAdapter(recyclerViewAdapterHome);

        tvBonusPromo = (TextView) findViewById(R.id.tv_BonusPromo);
        tvBonusPromo.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), ReportRewardBonusPromo.class);
                startActivity(intent);
                Toast.makeText(getApplicationContext(), "Bonus | Promo", Toast.LENGTH_SHORT).show();
            }
        });

        tvInfoNews = (TextView) findViewById(R.id.tv_InfoNews);
        tvInfoNews.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), InfoNews.class);
                startActivity(intent);
                Toast.makeText(getApplicationContext(), "Info | News", Toast.LENGTH_SHORT).show();
            }
        });

        tvNew = (TextView) findViewById(R.id.tv_New);
        tvNew.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), ReadProjectListingProperty.class);
                startActivity(intent);
                Toast.makeText(getApplicationContext(), "New", Toast.LENGTH_SHORT).show();
            }
        });

        loadData();
        //
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem mi) {
        switch (mi.getItemId()) {
            case R.id.item_one:
                break;
            case R.id.item_two:
                break;
        }

        return super.onOptionsItemSelected(mi);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_one, menu);
        getMenuInflater().inflate(R.menu.menu_two, menu);

        getMenuInflater().inflate(R.menu.menu_search, menu);
        final MenuItem mi = menu.findItem(R.id.item_search);
        final SearchView searchView = (SearchView) MenuItemCompat.getActionView(mi);
        searchView.setQueryHint("Search");
        searchView.setIconified(true);
        searchView.setOnQueryTextListener(this);
        return true;
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadData();
    }

    private void loadData() {
        Retrofit retrofit = new Retrofit.Builder().baseUrl(URL).addConverterFactory(GsonConverterFactory.create()).build();
        APIProjectListingProperty api = retrofit.create(APIProjectListingProperty.class);
        Call<ResponseModelProjectListingProperty> call = api.read();

        call.enqueue(new Callback<ResponseModelProjectListingProperty>() {
            @Override
            public void onResponse(Call<ResponseModelProjectListingProperty> call, Response<ResponseModelProjectListingProperty> response) {
                String gValue = response.body().getValue();
                pbNew.setVisibility(View.GONE);
                if (gValue.equals("1")) {
                    resultNext = response.body().getResult();
                    recyclerViewAdapterHome = new RecyclerViewAdapterHome(Home.this, resultNext);
                    rvNew.setAdapter(recyclerViewAdapterHome);
                }
            }

            @Override
            public void onFailure(Call<ResponseModelProjectListingProperty> call, Throwable throwable) { }
        });
    }

    @Override
    public boolean onQueryTextSubmit(String read) {return false;}

    @Override
    public boolean onQueryTextChange(String Read) {
        rvNew.setVisibility(View.GONE);
        pbNew.setVisibility(View.VISIBLE);
        Retrofit retrofit = new Retrofit.Builder().baseUrl(URL).addConverterFactory(GsonConverterFactory.create()).build();
        APIProjectListingProperty api = retrofit.create(APIProjectListingProperty.class);
        Call<ResponseModelProjectListingProperty> call = api.search(Read);

        call.enqueue(new Callback<ResponseModelProjectListingProperty>() {
            @Override
            public void onResponse(Call<ResponseModelProjectListingProperty> call, Response<ResponseModelProjectListingProperty> response) {
                String gValue = response.body().getValue();
                pbNew.setVisibility(View.GONE);
                rvNew.setVisibility(View.VISIBLE);
                if (gValue.equals("1")) {
                    resultNext = response.body().getResult();
                    recyclerViewAdapterHome = new RecyclerViewAdapterHome(Home.this, resultNext);
                    rvNew.setAdapter(recyclerViewAdapterHome);
                }
            }

            @Override
            public void onFailure(Call<ResponseModelProjectListingProperty> call, Throwable throwable) {
                pbNew.setVisibility(View.GONE);
            }
        });
        return true;
         */
    }
}
