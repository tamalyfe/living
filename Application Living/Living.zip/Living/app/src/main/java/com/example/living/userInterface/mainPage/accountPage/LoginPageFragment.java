package com.example.living.userInterface.mainPage.accountPage;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;

import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Toast;

import com.example.living.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class LoginPageFragment extends Fragment implements View.OnClickListener {
    private EditText etPassword;
    private CheckBox cbPassword;
    private Button bLogin;

    private Boolean isFABOpen = false;
    private FloatingActionButton fab, fabWhatsApp, fabTelegram, fabLine, fabLinkedIn, fabGmail, fabYmail, fabFacebook, fabInstagram, fabTwitter, fabYoutube;
    private Animation fab_close, fab_open, rotate_backward, rotate_forward;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.login_page_fragment, null);

        final Toolbar tLogin = v.findViewById(R.id.t_Login);
        tLogin.setNavigationIcon(R.drawable.ic_keyboard_arrow_left_dark_green_36dp);
        tLogin.setTitle("Login");
        tLogin.setTitleTextAppearance(getActivity(), R.style.setTitleTextAppearance);
        tLogin.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getActivity().finish();
            }
        });

        etPassword = v.findViewById(R.id.et_Password);
        cbPassword = v.findViewById(R.id.cb_Password);
        bLogin = v.findViewById(R.id.b_Login);

        cbPassword.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                if (!isChecked) {
                    etPassword.setTransformationMethod(PasswordTransformationMethod.getInstance());
                } else {
                    etPassword.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                }
            }
        });

        bLogin.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), AccountPageActivity.class);
                startActivity(intent);
                Toast.makeText(getActivity(), "Login", Toast.LENGTH_SHORT).show();
            }
        });

        fab = v.findViewById(R.id.fab);
        fabWhatsApp = v.findViewById(R.id.fab_WhatsApp);
        fabTelegram = v.findViewById(R.id.fab_Telegram);
        fabLine = v.findViewById(R.id.fab_Line);
        fabLinkedIn = v.findViewById(R.id.fab_LinkedIn);
        fabGmail = v.findViewById(R.id.fab_Gmail);
        fabYmail = v.findViewById(R.id.fab_Ymail);
        fabFacebook = v.findViewById(R.id.fab_Facebook);
        fabInstagram = v.findViewById(R.id.fab_Instagram);
        fabTwitter = v.findViewById(R.id.fab_Twitter);
        fabYoutube = v.findViewById(R.id.fab_Youtube);

        fab_close = AnimationUtils.loadAnimation(getContext(), R.anim.fab_close);
        fab_open = AnimationUtils.loadAnimation(getContext(), R.anim.fab_open);
        rotate_backward = AnimationUtils.loadAnimation(getContext(), R.anim.rotate_backward);
        rotate_forward = AnimationUtils.loadAnimation(getContext(), R.anim.rotate_forward);

        fab.setOnClickListener(this);
        fabWhatsApp.setOnClickListener(this);
        fabTelegram.setOnClickListener(this);
        fabLine.setOnClickListener(this);
        fabLinkedIn.setOnClickListener(this);
        fabGmail.setOnClickListener(this);
        fabYmail.setOnClickListener(this);
        fabFacebook.setOnClickListener(this);
        fabInstagram.setOnClickListener(this);
        fabTwitter.setOnClickListener(this);
        fabYoutube.setOnClickListener(this);

        return v;
        // return inflater.inflate(R.layout.fragment_login, null);
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();
        switch (id){
            case R.id.fab:
                animateFAB();
                break;
            case R.id.fab_WhatsApp:
                break;
            case R.id.fab_Telegram:
                break;
            case R.id.fab_Line:
                break;
            case R.id.fab_LinkedIn:
                break;
            case R.id.fab_Gmail:
                break;
            case R.id.fab_Ymail:
                break;
            case R.id.fab_Facebook:
                break;
            case R.id.fab_Instagram:
                break;
            case R.id.fab_Twitter:
                break;
            case R.id.fab_Youtube:
                break;
        }
    }

    public void animateFAB() {
        if(isFABOpen){
            isFABOpen = false;
            fab.startAnimation(rotate_backward);
            fabWhatsApp.startAnimation(fab_close);
            fabTelegram.startAnimation(fab_close);
            fabLine.startAnimation(fab_close);
            fabLinkedIn.startAnimation(fab_close);
            fabGmail.startAnimation(fab_close);
            fabYmail.startAnimation(fab_close);
            fabFacebook.startAnimation(fab_close);
            fabInstagram.startAnimation(fab_close);
            fabTwitter.startAnimation(fab_close);
            fabYoutube.startAnimation(fab_close);
            fabWhatsApp.setClickable(false);
            fabTelegram.setClickable(false);
            fabLine.setClickable(false);
            fabLinkedIn.setClickable(false);
            fabGmail.setClickable(false);
            fabYmail.setClickable(false);
            fabFacebook.setClickable(false);
            fabInstagram.setClickable(false);
            fabTwitter.setClickable(false);
            fabYoutube.setClickable(false);
        } else {
            isFABOpen = true;
            fab.startAnimation(rotate_forward);
            fabWhatsApp.startAnimation(fab_open);
            fabTelegram.startAnimation(fab_open);
            fabLine.startAnimation(fab_open);
            fabLinkedIn.startAnimation(fab_open);
            fabGmail.startAnimation(fab_open);
            fabYmail.startAnimation(fab_open);
            fabFacebook.startAnimation(fab_open);
            fabInstagram.startAnimation(fab_open);
            fabTwitter.startAnimation(fab_open);
            fabYoutube.startAnimation(fab_open);
            fabWhatsApp.setClickable(true);
            fabTelegram.setClickable(true);
            fabLine.setClickable(true);
            fabLinkedIn.setClickable(true);
            fabGmail.setClickable(true);
            fabYmail.setClickable(true);
            fabFacebook.setClickable(true);
            fabInstagram.setClickable(true);
            fabTwitter.setClickable(true);
            fabYoutube.setClickable(true);
        }
    }
}
