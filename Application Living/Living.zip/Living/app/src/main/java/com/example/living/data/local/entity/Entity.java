package com.example.living.data.local.entity;

public class Entity {
}
