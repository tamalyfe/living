package com.example.living.userInterface.mainPage.featurePage;

import android.content.Intent;
import android.os.Bundle;

import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.example.living.userInterface.mainPage.featurePage.ActivityRecordPage.ReadActivityRecordPage;
import com.example.living.userInterface.mainPage.featurePage.projectPage.ReadProjectPageActivity;
import com.example.living.userInterface.mainPage.featurePage.requestCustomerPage.ReadRequestCustomerPageActivity;
import com.example.living.userInterface.mainPage.featurePage.surveySchedulePage.ReadSurveySchedulePage;
import com.example.living.userInterface.mainPage.featurePage.recruitmentTeamPage.ReadRecruitmentTeamPageActivity;
import com.example.living.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class FeaturePageFragment extends Fragment {
    CardView cvReadProjectListingProperty;
    CardView cvReadTeam;
    CardView cvReadSurveySchedule;
    CardView cvReadRequestCustomerPage;
    CardView cvReportRewardBonusPromo;

    private FloatingActionButton fab;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.feature_page_fragment, null);

        // final Toolbar tTitle = v.findViewById(R.id.t_Title);
        // tTitle.setTitle("Title");
        // tTitle.setTitleTextAppearance(getContext(), R.style.setTitleTextAppearance);
        // tTitle.setTitleTextColor(getResources().getColor(R.color.white));
        // tTitle.setTitleTextColor(Color.parseColor("#FFFFFFFF"));

        /*
        FloatingActionButton fabLink = v.findViewById(R.id.fab_Link);
        fabLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getContext(), Link.class);
                startActivity(intent);
                Toast.makeText(getContext(), "Link", Toast.LENGTH_SHORT).show();
            }
        });

        FloatingActionButton fabWishList = v.findViewById(R.id.fab_WishList);
        fabWishList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getContext(), WishList.class);
                startActivity(intent);
                Toast.makeText(getContext(), "WishList", Toast.LENGTH_SHORT).show();
            }
        });

        FloatingActionButton fabNotification = v.findViewById(R.id.fab_Notification);
        fabNotification.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getContext(), Notification.class);
                startActivity(intent);
                Toast.makeText(getContext(), "Notification", Toast.LENGTH_SHORT).show();
            }
        });

        fab = v.findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(getContext(), FragmentActivityPopUp.class);
                startActivity(intent);
                Toast.makeText(getContext(), "fab", Toast.LENGTH_SHORT).show();
            }
        });
         */

        cvReadProjectListingProperty = v.findViewById(R.id.cv_ReadProjectListingProperty);
        cvReadProjectListingProperty.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), ReadProjectPageActivity.class);
                startActivity(intent);
                Toast.makeText(getActivity(), "Read Project", Toast.LENGTH_SHORT).show();
            }
        });

        cvReadTeam = v.findViewById(R.id.cv_ReadTeam);
        cvReadTeam.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), ReadRecruitmentTeamPageActivity.class);
                startActivity(intent);
                Toast.makeText(getActivity(), "Read Team", Toast.LENGTH_SHORT).show();
            }
        });

        cvReadSurveySchedule = v.findViewById(R.id.cv_ReadSurveySchedule);
        cvReadSurveySchedule.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), ReadSurveySchedulePage.class);
                startActivity(intent);
                Toast.makeText(getActivity(), "Read Survey Schedule", Toast.LENGTH_SHORT).show();
            }
        });

        cvReadRequestCustomerPage = v.findViewById(R.id.cv_ReadRequestCustomerPage);
        cvReadRequestCustomerPage.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), ReadRequestCustomerPageActivity.class);
                startActivity(intent);
                Toast.makeText(getActivity(), "Read Request Customer Page", Toast.LENGTH_SHORT).show();
            }
        });

        cvReportRewardBonusPromo = v.findViewById(R.id.cvActivityReport);
        cvReportRewardBonusPromo.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), ReadActivityRecordPage.class);
                startActivity(intent);
                Toast.makeText(getActivity(), "Report >| Reward | Bonus | Promo", Toast.LENGTH_SHORT).show();
            }
        });

        return v;
        // return inflater.inflate(R.layout.feature_fragment, null);
    }
}

